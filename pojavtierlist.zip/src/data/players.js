export const players = {
  "Stony": {
    name: "Stony",
    message: "One of the best NethPot players!",
    tiers: {
      "Netherite Potion": "HT1",
      "Diamond Pot": "HT2",
      "Sword": "LT1",
      "Axe": "HT3",
      "SMP": "HT1",
      "Cpvp": "HT2",
      "UHC": "LT2"
    }
  },
  "xicz": {
    name: "xicz",
    message: "Top 1 PVPer.",
    tiers: {
      "Netherite Potion": "HT1",
      "Diamond Pot": "HT1",
      "Sword": "HT1",
      "Axe": "HT2",
      "SMP": "HT3",
      "Cpvp": "HT1",
      "UHC": "HT2"
    }
  }
}