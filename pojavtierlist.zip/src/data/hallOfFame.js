export const hallOfFame = [
  {
    name: "Stony",
    message: "Creator of the best PvP scanner!",
    image: "Stony"
  },
  {
    name: "xicz",
    message: "Legend of NethPot!",
    image: "xicz"
  }
]